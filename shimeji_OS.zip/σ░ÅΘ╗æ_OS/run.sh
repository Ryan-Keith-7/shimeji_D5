java -jar black_OS.app/Contents/Resources/Java/Shimeji.jar

