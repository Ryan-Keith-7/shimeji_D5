java -jar white_OS.app/Contents/Resources/Java/Shimeji.jar

